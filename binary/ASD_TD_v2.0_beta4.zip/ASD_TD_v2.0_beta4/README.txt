ENGLISH
==============================================
== ASD - Tower Defense version 2.0 (beta 4) ==
==============================================

Starting the game:
--------------
0. Extract the content of the archive (.zip)

1. Just double-click on the file "ASD_TD_2.0.exe" if you're running Windows.
   For Linux and Mac, run the file "ASD_TD_2.0.sh" (do not forget to give him the necessary rights).
   
2. Same principle to the registration server, except that the file is named
   "ASD_TD_ServeurEnregistrement. [exe | sh]".

2. If it does not work, make sure you have the latest version of Java
It is available here: http://www.java.com/fr/
   

Attention messages may appear in brackets at the
game, this is quite normal. This helps us to fix bugs.
Do you just not worry.
   
Enjoy!

The ASD_TD team.