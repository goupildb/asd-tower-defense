#!/bin/bash

java -jar ASD_TD_ServeurEnregistrement.jar
