#!/bin/bash

java -jar ASD_TD_2.0.jar
